export type CountryCode = 'FR' | 'NG' | 'IN' | 'GB' | 'TZ' | 'SA' | 'DE' | 'CA' | 'CD';

export interface ProjectLink {
  label: string;
  url: string;
  secondary?: boolean;
}

export interface ProjectItem {
  id: string;
  idx: string;
  title: string;
  category: 'music' | 'travel' | 'commerce' | 'social' | 'fintech' | 'services';
  type: string;
  country: string;
  countryCode: CountryCode;
  platform: string;
  description: string;
  buildNote: string;
  stack: string[];
  accent: string;
  links: ProjectLink[];
}
