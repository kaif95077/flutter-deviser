import React, { useState, useEffect } from 'react';
import { projectsData } from './data/projects';
import { ProjectCard } from './components/ProjectCard';
import { ProjectModal } from './components/ProjectModal';
import { BookingModal } from './components/BookingModal';
import { Cursor } from './components/Cursor';

const LOGO_SRC = "/logo.svg";

export default function App() {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [scrollWidth, setScrollWidth] = useState('0%');

  // Enforce Light Mode Only
  useEffect(() => {
    document.documentElement.classList.remove('dark-mode');
    localStorage.removeItem('fd-theme-mode-v3');
    localStorage.removeItem('fd-theme-mode');
  }, []);

  // Scroll Progress Bar
  useEffect(() => {
    const handleScroll = () => {
      const doc = document.documentElement;
      const total = doc.scrollHeight - doc.clientHeight;
      const progress = total > 0 ? (doc.scrollTop / total) * 100 : 0;
      setScrollWidth(`${progress}%`);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // 10-Second Booking Popup
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsBookingModalOpen(true);
    }, 10000);
    return () => clearTimeout(timer);
  }, []);

  // Filter project cards
  const filteredProjects = selectedFilter === 'all'
    ? projectsData
    : projectsData.filter((p) => p.category === selectedFilter);

  // Category counts
  const counts = {
    all: projectsData.length,
    music: projectsData.filter((p) => p.category === 'music').length,
    travel: projectsData.filter((p) => p.category === 'travel').length,
    commerce: projectsData.filter((p) => p.category === 'commerce').length,
    social: projectsData.filter((p) => p.category === 'social').length,
    fintech: projectsData.filter((p) => p.category === 'fintech').length,
    services: projectsData.filter((p) => p.category === 'services').length,
  };

  return (
    <>
      {/* Dynamic Cursor */}
      <Cursor />

      {/* Top Build Progress Bar */}
      <div id="buildbar" style={{ width: scrollWidth }}></div>

      <a className="skip-link" href="#main">
        Skip to content
      </a>

      {/* Navigation */}
      <header className="nav">
        <div className="container nav-row">
          <div className="wordmark">
            <div className="logo-box">
              <img src={LOGO_SRC} alt="Flutter Deviser logo" />
            </div>
            <span className="wordmark-text">
              FLUTTER<span className="dot">.</span>DEVISER
            </span>
          </div>

          <nav className="links">
            <a href="#work">Work</a>
            <a href="#feedback">Reviews</a>
            <a href="#services">Services</a>
            <a href="#contact">Contact</a>
          </nav>

          <div className="nav-actions">
            <span className="status-chip">
              <span className="status-dot"></span>Available
            </span>
            <div className="nav-contact-actions">
              <a
                href="https://api.whatsapp.com/send?phone=917838086198"
                target="_blank"
                rel="noopener noreferrer"
                className="btn whatsapp-btn"
                aria-label="DM us on WhatsApp"
              >
                <span className="wa-icon" aria-hidden="true">◔</span> DM us on WhatsApp
              </a>
              <a
                href="https://cal.com/flutter-deviser/app-development"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary nav-cta"
              >
                Book a Free Call
              </a>
            </div>

            <button
              className="menu-btn"
              id="menuOpen"
              aria-label="Open menu"
              aria-expanded={isMobileMenuOpen}
              onClick={() => setIsMobileMenuOpen(true)}
            >
              Menu [☰]
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <div
        className={`mob-overlay ${isMobileMenuOpen ? 'open' : ''}`}
        id="mobOverlay"
        role="dialog"
        aria-modal="true"
        aria-label="Navigation menu"
      >
        <div className="mob-top">
          <div className="wordmark">
            <div className="logo-box">
              <img src={LOGO_SRC} alt="Flutter Deviser logo" />
            </div>
            <span className="wordmark-text">
              FLUTTER<span className="dot">.</span>DEVISER
            </span>
          </div>
          <button
            className="menu-btn"
            id="menuClose"
            aria-label="Close menu"
            style={{ display: 'inline-flex' }}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Close [✕]
          </button>
        </div>

        <ul>
          <li>
            <a href="#work" className="mnav" onClick={() => setIsMobileMenuOpen(false)}>
              Work
            </a>
          </li>
          <li>
            <a href="#feedback" className="mnav" onClick={() => setIsMobileMenuOpen(false)}>
              Reviews
            </a>
          </li>
          <li>
            <a href="#services" className="mnav" onClick={() => setIsMobileMenuOpen(false)}>
              Services
            </a>
          </li>
          <li>
            <a href="#contact" className="mnav" onClick={() => setIsMobileMenuOpen(false)}>
              Contact
            </a>
          </li>
        </ul>

        <div className="mob-cta">
          <a
            href="https://cal.com/flutter-deviser/app-development"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-primary"
          >
            Book a Free Call
          </a>
          <div className="menu-or-divider" aria-hidden="true">
            <span>OR</span>
          </div>
          <a
            href="https://api.whatsapp.com/send?phone=917838086198"
            target="_blank"
            rel="noopener noreferrer"
            className="btn whatsapp-btn"
          >
            DM us on WhatsApp
          </a>
        </div>
        <p className="mob-info">
          <span className="status-dot"></span>Available · Q3 2026 · 2 slots left
        </p>
      </div>

      {/* Animated Ticker */}
      <div className="ticker-wrap">
        <div className="ticker-track">
          <span>// 25+ APPS SHIPPED</span>
          <span>// 250K+ COMMUNITY MEMBERS</span>
          <span>// AVG. 6-WEEK TURNAROUND</span>
          <span>// FLUTTER · FIREBASE · REST · GRAPHQL</span>
          <span>// Q3 2026 · ONLY 2 SLOTS LEFT</span>
          <span>// 246K INSTAGRAM FOLLOWERS</span>
          <span>// iOS &amp; ANDROID FROM ONE CODEBASE</span>
          <span>// 25+ APPS SHIPPED</span>
          <span>// 250K+ COMMUNITY MEMBERS</span>
          <span>// AVG. 6-WEEK TURNAROUND</span>
          <span>// FLUTTER · FIREBASE · REST · GRAPHQL</span>
          <span>// Q3 2026 · ONLY 2 SLOTS LEFT</span>
          <span>// 246K INSTAGRAM FOLLOWERS</span>
          <span>// iOS &amp; ANDROID FROM ONE CODEBASE</span>
        </div>
      </div>

      <main id="main">
        {/* HERO SECTION */}
        <section className="hero bg-void" id="hero">
          <div className="container hero-grid">
            <div>
              <span className="eyebrow">
                Mobile app development studio<span className="blink"></span>
              </span>
              <h1>
                <span className="hero-line-large">WE BUILD</span>
                <span className="hero-line-large">APPS</span>
                <span className="hero-line-small">THAT SHIP.</span>
              </h1>
              <p className="hero-sub">
                Flutter Deviser designs, codes, and launches mobile apps for founders who need a
                working product — not another deck. One team, one codebase, two platforms.
              </p>
              <div className="hero-ctas">
                <a
                  href="https://cal.com/flutter-deviser/app-development"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-primary"
                >
                  Book a Free Call
                </a>
                <a href="#work" className="btn btn-outline">
                  View the Projects
                </a>
              </div>
              <p className="hero-meta">
                → <strong>25+</strong> apps shipped · iOS &amp; Android · avg.{' '}
                <strong>6-week</strong> delivery · <strong>250K+</strong> community
              </p>
            </div>

            <div className="hero-art bauhaus-flat-art" aria-hidden="true">
              <div className="flat-panel">
                <div className="flat-panel-top">
                  <span>FLUTTER DEVISER</span>
                  <span>01 / BUILD</span>
                </div>
                <div className="flat-panel-main">
                  <div className="flat-number">01</div>
                  <div className="flat-copy">
                    FROM<br />
                    IDEA<br />
                    TO<br />
                    APP.
                  </div>
                  <div className="flat-red-block"></div>
                  <div className="flat-yellow-block"></div>
                </div>
                <div className="flat-panel-bottom">
                  <span>IOS + ANDROID</span>
                  <span>ONE CODEBASE</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SPEC SHEET */}
        <section className="bg-paper section" id="spec">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">The spec sheet</span>
              <h2>Numbers, not adjectives.</h2>
            </div>
            <div className="spec-grid">
              <div className="spec-cell">
                <span className="spec-tag">[01]</span>
                <span className="spec-num">25+</span>
                <span className="spec-label">Apps shipped</span>
              </div>
              <div className="spec-cell">
                <span className="spec-tag">[02]</span>
                <span className="spec-num">250K+</span>
                <span className="spec-label">Community members</span>
              </div>
              <div className="spec-cell">
                <span className="spec-tag">[03]</span>
                <span className="spec-num">6 wks</span>
                <span className="spec-label">Avg. delivery time</span>
              </div>
              <div className="spec-cell">
                <span className="spec-tag">[04]</span>
                <span className="spec-num">4.9★</span>
                <span className="spec-label">Client rating</span>
              </div>
            </div>
          </div>
        </section>

        {/* WORK SECTION */}
        <section className="section bg-void" id="work">
          <div className="container">
            <div className="section-head" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '20px' }}>
              <div>
                <span className="eyebrow">The projects</span>
                <h2>Recent ships.</h2>
                <p>From blueprint to App Store. Filter by category, or tap a card for build notes.</p>
              </div>
              <button
                type="button"
                className="btn btn-outline"
                style={{ fontSize: '11px', padding: '10px 16px' }}
                onClick={() => setIsProjectModalOpen(true)}
              >
                Open Project Showcase ↗
              </button>
            </div>

            {/* Work Category Filters */}
            <div className="work-filters" role="tablist" aria-label="Filter projects by category">
              <button
                type="button"
                className={`wf-btn ${selectedFilter === 'all' ? 'active' : ''}`}
                onClick={() => setSelectedFilter('all')}
              >
                All<span className="wf-count">{counts.all}</span>
              </button>
              <button
                type="button"
                className={`wf-btn ${selectedFilter === 'music' ? 'active' : ''}`}
                onClick={() => setSelectedFilter('music')}
              >
                Music<span className="wf-count">{String(counts.music).padStart(2, '0')}</span>
              </button>
              <button
                type="button"
                className={`wf-btn ${selectedFilter === 'travel' ? 'active' : ''}`}
                onClick={() => setSelectedFilter('travel')}
              >
                Travel<span className="wf-count">{String(counts.travel).padStart(2, '0')}</span>
              </button>
              <button
                type="button"
                className={`wf-btn ${selectedFilter === 'commerce' ? 'active' : ''}`}
                onClick={() => setSelectedFilter('commerce')}
              >
                Commerce<span className="wf-count">{String(counts.commerce).padStart(2, '0')}</span>
              </button>
              <button
                type="button"
                className={`wf-btn ${selectedFilter === 'social' ? 'active' : ''}`}
                onClick={() => setSelectedFilter('social')}
              >
                Social<span className="wf-count">{String(counts.social).padStart(2, '0')}</span>
              </button>
              <button
                type="button"
                className={`wf-btn ${selectedFilter === 'fintech' ? 'active' : ''}`}
                onClick={() => setSelectedFilter('fintech')}
              >
                Fintech<span className="wf-count">{String(counts.fintech).padStart(2, '0')}</span>
              </button>
              <button
                type="button"
                className={`wf-btn ${selectedFilter === 'services' ? 'active' : ''}`}
                onClick={() => setSelectedFilter('services')}
              >
                Services<span className="wf-count">{String(counts.services).padStart(2, '0')}</span>
              </button>
            </div>

            {/* Work Grid */}
            <div className="work-grid" id="workGrid">
              {filteredProjects.map((project, idx) => (
                <ProjectCard key={project.id} project={project} delayIndex={idx} />
              ))}

              {/* More Builds Card */}
              {selectedFilter === 'all' && (
                <div
                  className="work-card more-card"
                  data-cat="all"
                  style={{
                    ['--accent' as string]: 'var(--signal)',
                    ['--d' as string]: filteredProjects.length,
                  }}
                >
                  <div className="wc-head" style={{ width: '100%' }}>
                    <span className="wc-idx">+</span>
                    <span className="wc-status">All shipped</span>
                  </div>
                  <div className="more-num">
                    <span>10</span>
                    <span className="plus">+</span>
                  </div>
                  <h3 className="wc-title">More Builds</h3>
                  <p className="wc-desc">
                    Full case studies available on request. Book a call to see the complete portfolio.
                  </p>
                  <a
                    href="https://cal.com/flutter-deviser/app-development"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-primary"
                  >
                    Book a Call ↗
                  </a>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* CLIENT FEEDBACK */}
        <section className="section bg-paper client-feedback-section" id="feedback">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">Client feedback</span>
              <h2>Good work.<br />Good words.</h2>
              <p>Direct words from founders we have designed, built, and shipped mobile apps with.</p>
            </div>

            <div className="feedback-grid">
              <article className="feedback-card">
                <div className="feedback-top">
                  <span className="feedback-stars" aria-label="5 out of 5 stars">★★★★★</span>
                  <span className="feedback-index">01</span>
                </div>
                <p className="feedback-quote">
                  “Fast, thoughtful, and genuinely easy to work with. The final product felt polished from day one.”
                </p>
                <div className="feedback-client">
                  <strong>Nason Karol</strong>
                  <span>ANZA Cash</span>
                </div>
              </article>

              <article className="feedback-card">
                <div className="feedback-top">
                  <span className="feedback-stars" aria-label="5 out of 5 stars">★★★★★</span>
                  <span className="feedback-index">02</span>
                </div>
                <p className="feedback-quote">
                  “Great execution and clear communication throughout. They turned the idea into something real, quickly.”
                </p>
                <div className="feedback-client">
                  <strong>Justin</strong>
                  <span>eSIM Dual</span>
                </div>
              </article>

              <article className="feedback-card">
                <div className="feedback-top">
                  <span className="feedback-stars" aria-label="5 out of 5 stars">★★★★★</span>
                  <span className="feedback-index">03</span>
                </div>
                <p className="feedback-quote">
                  “Professional, creative, and responsive. The attention to detail made a big difference.”
                </p>
                <div className="feedback-client">
                  <strong>Hermione Kamga</strong>
                  <span>Sogeht</span>
                </div>
              </article>

              <article className="feedback-card">
                <div className="feedback-top">
                  <span className="feedback-stars" aria-label="5 out of 5 stars">★★★★★</span>
                  <span className="feedback-index">04</span>
                </div>
                <p className="feedback-quote">
                  “A smooth development experience with strong product thinking and a sharp final result.”
                </p>
                <div className="feedback-client">
                  <strong>Basil Mustapha</strong>
                  <span>BamScores</span>
                </div>
              </article>

              <article className="feedback-card">
                <div className="feedback-top">
                  <span className="feedback-stars" aria-label="5 out of 5 stars">★★★★★</span>
                  <span className="feedback-index">05</span>
                </div>
                <p className="feedback-quote">
                  “They understood what we needed and delivered with speed, clarity, and attention to the details that matter.”
                </p>
                <div className="feedback-client">
                  <strong>James Penny</strong>
                  <span>Pinpoint</span>
                </div>
              </article>
            </div>
          </div>
        </section>

        {/* GLOBAL CLIENTS */}
        <section className="section bg-void global-clients-section" id="global-clients">
          <div className="container">
            <div className="global-head">
              <div>
                <span className="eyebrow">Built without borders</span>
                <h2>Clients from<br /><span>all over the world.</span></h2>
              </div>
              <p>From early-stage founders to growing businesses, we build products for teams across continents.</p>
            </div>

            <div className="world-stage">
              <div className="world-grid"></div>
              <div className="world-orbit world-orbit-one"></div>
              <div className="world-orbit world-orbit-two"></div>
              <div className="world-core">
                <span className="world-core-top">FLUTTER DEVISER</span>
                <strong>GLOBAL</strong>
                <span className="world-core-bottom">PRODUCT PARTNERS</span>
              </div>

              <div className="world-node node-nigeria">
                <i></i><span>Nigeria</span><small>NG</small>
              </div>
              <div className="world-node node-germany">
                <i></i><span>Germany</span><small>DE</small>
              </div>
              <div className="world-node node-canada">
                <i></i><span>Canada</span><small>CA</small>
              </div>
              <div className="world-node node-france">
                <i></i><span>France</span><small>FR</small>
              </div>
              <div className="world-node node-tanzania">
                <i></i><span>Tanzania</span><small>TZ</small>
              </div>
              <div className="world-node node-india">
                <i></i><span>India</span><small>IN</small>
              </div>
              <div className="world-node node-saudi">
                <i></i><span>Saudi Arabia</span><small>SA</small>
              </div>
              <div className="world-node node-congo">
                <i></i><span>DR Congo</span><small>CD</small>
              </div>
              <div className="world-node node-portugal">
                <i></i><span>Portugal</span><small>PT</small>
              </div>
              <div className="world-node node-usa">
                <i></i><span>USA</span><small>US</small>
              </div>
            </div>

            <div className="country-strip">
              <div><strong>NG</strong><span>Nigeria</span></div>
              <div><strong>DE</strong><span>Germany</span></div>
              <div><strong>CA</strong><span>Canada</span></div>
              <div><strong>FR</strong><span>France</span></div>
              <div><strong>TZ</strong><span>Tanzania</span></div>
              <div><strong>IN</strong><span>India</span></div>
              <div><strong>SA</strong><span>Saudi Arabia</span></div>
              <div><strong>CD</strong><span>DR Congo</span></div>
              <div><strong>PT</strong><span>Portugal</span></div>
              <div><strong>US</strong><span>USA</span></div>
            </div>
          </div>
        </section>

        {/* SERVICES SECTION (MOVED TO BOTTOM) */}
        <section className="section bg-paper" id="services">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">What we build</span>
              <h2>Five services. One codebase.</h2>
              <p>Everything a Flutter app needs to go from idea to App Store, handled by one team.</p>
            </div>
            <div className="svc-grid">
              <div className="svc-card">
                <span className="svc-tag">Service / 01</span>
                <h3>Flutter App Development</h3>
                <p>Native-feeling iOS and Android apps from a single Flutter codebase.</p>
              </div>
              <div className="svc-card">
                <span className="svc-tag">Service / 02</span>
                <h3>UI/UX Design</h3>
                <p>Interfaces wireframed, tested, and signed off before a single line of code ships.</p>
              </div>
              <div className="svc-card">
                <span className="svc-tag">Service / 03</span>
                <h3>Backend &amp; API Integration</h3>
                <p>Firebase, REST, GraphQL, auth, and payments — wired in and battle-tested.</p>
              </div>
              <div className="svc-card">
                <span className="svc-tag">Service / 04</span>
                <h3>MVP Sprints</h3>
                <p>A working build in your hands in weeks — built to validate, not to impress.</p>
              </div>
              <div className="svc-card">
                <span className="svc-tag">Service / 05</span>
                <h3>App Store Launch &amp; Support</h3>
                <p>Submission, review, and the post-launch fixes that always come up.</p>
              </div>
              <div className="svc-card" style={{ background: 'var(--signal)', color: '#fff', borderRight: 'none' }}>
                <span className="svc-tag" style={{ color: 'rgba(255,255,255,.6)' }}>Service / 06</span>
                <h3>Need Something Else?</h3>
                <p style={{ color: 'rgba(255,255,255,.8)' }}>Tell us the build. If it ships on a phone, we can probably scope it.</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA SECTION */}
        <section className="section bg-void cta-section" id="contact">
          <div className="container">
            <span className="eyebrow" style={{ justifyContent: 'center' }}>
              Ready when you are
            </span>
            <h2>
              Start your<br />build.
            </h2>
            <p>Tell us what the app needs to do. We'll tell you what it costs and when it ships.</p>
            <div className="cta-btns">
              <a
                href="https://cal.com/flutter-deviser/app-development"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary"
              >
                Book a Free Call
              </a>
              <a
                href="https://api.whatsapp.com/send?phone=917838086198"
                target="_blank"
                rel="noopener noreferrer"
                className="btn whatsapp-btn"
              >
                <span className="wa-icon" aria-hidden="true">◔</span> DM us on WhatsApp
              </a>
              <a
                href="https://www.instagram.com/flutter.deviser/"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-outline"
              >
                DM on Instagram
              </a>
              <a href="mailto:flutterdeviser@gmail.com" className="btn btn-outline">
                Email the Team
              </a>
            </div>
            <p className="cta-note">
              Now booking Q3 2026 · only 2 slots left<span className="blink" style={{ marginLeft: '6px' }}></span>
            </p>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-void">
        <div className="container">
          <div className="footer-row">
            <div className="wordmark">
              <div className="logo-box">
                <img src={LOGO_SRC} alt="Flutter Deviser logo" />
              </div>
              <span className="wordmark-text">
                FLUTTER<span className="dot">.</span>DEVISER
              </span>
            </div>
            <div className="footer-links">
              <a href="#work">Work</a>
              <a href="#feedback">Reviews</a>
              <a href="#services">Services</a>
              <a href="#contact">Contact</a>
            </div>
          </div>
          <div className="footer-bottom">
            <span>© 2026 Flutter Deviser. All rights reserved.</span>
            <span>Build v2.5.0 · compiled 2026</span>
          </div>
        </div>
      </footer>

      {/* Project Showcase Modal */}
      <ProjectModal
        projects={projectsData}
        isOpen={isProjectModalOpen}
        onClose={() => setIsProjectModalOpen(false)}
      />

      {/* 10-Second Booking Modal */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
      />
    </>
  );
}
