import React, { useEffect, useRef } from 'react';

export const Cursor: React.FC = () => {
  const outerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!window.matchMedia('(pointer:fine)').matches) return;

    const outer = outerRef.current;
    const inner = innerRef.current;
    const label = labelRef.current;
    if (!outer || !inner || !label) return;

    let mx = window.innerWidth / 2;
    let my = window.innerHeight / 2;
    let rx = mx;
    let ry = my;
    let labelTimer: any = null;
    let animFrameId: number;

    const onMouseMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
      inner.style.left = `${mx}px`;
      inner.style.top = `${my}px`;
      label.style.left = `${mx}px`;
      label.style.top = `${my}px`;
    };

    const onMouseDown = () => {
      outer.classList.add('cursor-click');
    };

    const onMouseUp = () => {
      outer.classList.remove('cursor-click');
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);

    const animate = () => {
      rx += (mx - rx) * 0.17;
      ry += (my - ry) * 0.17;
      outer.style.left = `${rx}px`;
      outer.style.top = `${ry}px`;
      animFrameId = requestAnimationFrame(animate);
    };
    animFrameId = requestAnimationFrame(animate);

    const handleMouseEnterInteractive = (e: Event) => {
      const target = e.currentTarget as HTMLElement;
      if (
        target.matches(
          '.work-card, .svc-card, .feedback-card, .proj-slide, .booking-link'
        )
      ) {
        outer.classList.remove('cursor-link', 'cursor-text');
        outer.classList.add('cursor-card');
      } else {
        outer.classList.remove('cursor-card', 'cursor-text');
        outer.classList.add('cursor-link');
      }
      inner.classList.add('cursor-active');
    };

    const handleMouseLeaveInteractive = () => {
      outer.classList.remove('cursor-link', 'cursor-card');
      inner.classList.remove('cursor-active');
    };

    const handleMouseEnterText = () => {
      outer.classList.remove('cursor-link', 'cursor-card');
      outer.classList.add('cursor-text');
    };

    const handleMouseLeaveText = () => {
      outer.classList.remove('cursor-text');
    };

    const interactives = document.querySelectorAll(
      'a, button, .work-card, .svc-card, .feedback-card, .proj-slide, .booking-link, .wc-toggle'
    );
    interactives.forEach((el) => {
      el.addEventListener('mouseenter', handleMouseEnterInteractive);
      el.addEventListener('mouseleave', handleMouseLeaveInteractive);
    });

    const textElements = document.querySelectorAll('h1, h2, h3, .eyebrow');
    textElements.forEach((el) => {
      el.addEventListener('mouseenter', handleMouseEnterText);
      el.addEventListener('mouseleave', handleMouseLeaveText);
    });

    // Section entry label observer
    const sections: [string, string][] = [
      ['hero', '01 / HOME'],
      ['spec', '02 / NUMBERS'],
      ['work', '03 / RECENT SHIPS'],
      ['feedback', '04 / FEEDBACK'],
      ['global-clients', '05 / GLOBAL CLIENTS'],
      ['services', '06 / SERVICES'],
      ['contact', '07 / START A PROJECT'],
    ];

    const setLabel = (text: string) => {
      clearTimeout(labelTimer);
      label.textContent = text;
      label.classList.add('show');
      labelTimer = setTimeout(() => {
        label.classList.remove('show');
      }, 1200);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const secName = entry.target.getAttribute('data-cursor-name');
            if (secName) setLabel(secName);
          }
        });
      },
      { threshold: 0.25 }
    );

    sections.forEach(([id, name]) => {
      const el = document.getElementById(id);
      if (el) {
        el.setAttribute('data-cursor-name', name);
        observer.observe(el);
      }
    });

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      interactives.forEach((el) => {
        el.removeEventListener('mouseenter', handleMouseEnterInteractive);
        el.removeEventListener('mouseleave', handleMouseLeaveInteractive);
      });
      textElements.forEach((el) => {
        el.removeEventListener('mouseenter', handleMouseEnterText);
        el.removeEventListener('mouseleave', handleMouseLeaveText);
      });
      observer.disconnect();
    };
  }, []);

  return (
    <>
      <div id="cr-outer" ref={outerRef}></div>
      <div id="cr-inner" ref={innerRef}></div>
      <div id="cr-label" ref={labelRef}></div>
    </>
  );
};
