import React, { useEffect, useState, useRef } from 'react';
import { ProjectItem } from '../types';
import { Flag } from './Flag';

interface ProjectModalProps {
  projects: ProjectItem[];
  isOpen: boolean;
  onClose: () => void;
  initialIndex?: number;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  projects,
  isOpen,
  onClose,
  initialIndex = 0,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const touchStartX = useRef(0);
  const isDragging = useRef(false);

  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(initialIndex);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [isOpen, initialIndex]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'ArrowRight') {
        setCurrentIndex((prev) => Math.min(projects.length - 1, prev + 1));
      } else if (e.key === 'ArrowLeft') {
        setCurrentIndex((prev) => Math.max(0, prev - 1));
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, projects.length, onClose]);

  if (!isOpen) return null;

  const currentProject = projects[currentIndex];

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    isDragging.current = true;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!isDragging.current) return;
    isDragging.current = false;
    const diff = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(diff) > 40) {
      if (diff < 0 && currentIndex < projects.length - 1) {
        setCurrentIndex((prev) => prev + 1);
      } else if (diff > 0 && currentIndex > 0) {
        setCurrentIndex((prev) => prev - 1);
      }
    }
  };

  return (
    <div
      id="proj-overlay"
      className="visible"
      role="dialog"
      aria-modal="true"
      aria-label="Our shipped projects"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="proj-popup">
        <div className="proj-topbar">
          <span className="proj-topbar-label">
            // {projects.length} Apps Shipped · Projects
          </span>
          <div className="proj-topbar-right">
            <span className="proj-counter" id="projCounter">
              {currentIndex + 1} / {projects.length}
            </span>
            <button
              id="projCloseBtn"
              type="button"
              className="proj-close-btn"
              onClick={onClose}
              aria-label="Close project showcase"
            >
              Close ✕
            </button>
          </div>
        </div>

        <div
          className="proj-viewport"
          id="projViewport"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          <div
            className="proj-track"
            style={{
              transform: `translateX(-${currentIndex * 100}%)`,
              display: 'flex',
              transition: 'transform 0.4s cubic-bezier(0.2, 0.8, 0.2, 1)',
            }}
          >
            {projects.map((proj) => (
              <div
                key={proj.id}
                className="proj-slide"
                style={{ ['--slide-accent' as string]: proj.accent }}
              >
                <div className="ps-eyebrow">
                  <div className="ps-eyebrow-left" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="ps-type">{proj.type}</span>
                    <div className="wc-flag-badge" title={proj.country}>
                      <Flag countryCode={proj.countryCode} width={16} height={11} />
                      <span className="wc-flag-name">{proj.country}</span>
                    </div>
                  </div>
                  <span className="ps-platform">{proj.platform}</span>
                </div>

                <h2 className="ps-title">{proj.title}</h2>
                <p className="ps-desc">{proj.description}</p>
                <div className="ps-stack">
                  {proj.stack.map((s) => (
                    <span key={s}>{s}</span>
                  ))}
                </div>

                <div className="ps-links">
                  {proj.links.map((link) => (
                    <a
                      key={link.label}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={link.secondary ? 'secondary' : ''}
                    >
                      {link.label}
                    </a>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="proj-nav">
          <button
            type="button"
            className="proj-arrow"
            id="projPrev"
            disabled={currentIndex === 0}
            onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
          >
            ← Prev
          </button>
          <div className="proj-dots" id="projDots">
            {projects.map((_, idx) => (
              <button
                key={idx}
                type="button"
                className={`proj-dot ${idx === currentIndex ? 'active' : ''}`}
                onClick={() => setCurrentIndex(idx)}
                aria-label={`Project ${idx + 1}`}
              />
            ))}
          </div>
          <button
            type="button"
            className="proj-arrow"
            id="projNext"
            disabled={currentIndex === projects.length - 1}
            onClick={() => setCurrentIndex((prev) => Math.min(projects.length - 1, prev + 1))}
          >
            Next →
          </button>
        </div>
        <p className="proj-swipe-hint">Swipe or use arrow keys to browse all {projects.length} projects</p>
      </div>
    </div>
  );
};
