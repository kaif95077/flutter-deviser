import React, { useState } from 'react';
import { ProjectItem } from '../types';
import { Flag } from './Flag';

interface ProjectCardProps {
  project: ProjectItem;
  delayIndex?: number;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, delayIndex = 0 }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty('--mx', `${e.clientX - rect.left}px`);
    e.currentTarget.style.setProperty('--my', `${e.clientY - rect.top}px`);
  };

  return (
    <div
      id={`project-${project.id}`}
      className={`work-card ${isOpen ? 'is-open' : ''}`}
      data-cat={project.category}
      style={{
        ['--accent' as string]: project.accent,
        ['--d' as string]: delayIndex,
      }}
      onMouseMove={handleMouseMove}
    >
      {/* Top Header Row with Index on left, and Country Flag + Status on the top right corner */}
      <div className="wc-head">
        <span className="wc-idx">{project.idx}</span>
        <div className="wc-head-right">
          <div
            id={`flag-${project.id}`}
            className="wc-flag-badge"
            title={`${project.title} · ${project.country}`}
            aria-label={`Country: ${project.country}`}
          >
            <Flag countryCode={project.countryCode} width={18} height={12} />
            <span className="wc-flag-name">{project.country}</span>
          </div>
          <span className="wc-status">Shipped</span>
        </div>
      </div>

      <span className="wc-cat">{project.type}</span>
      <h3 className="wc-title">{project.title}</h3>
      <p className="wc-desc">{project.description}</p>
      <span className="wc-plat">{project.platform}</span>

      <button
        type="button"
        className="wc-toggle"
        aria-expanded={isOpen}
        aria-controls={`panel-${project.id}`}
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(!isOpen);
        }}
      >
        <span>Project details</span>
        <span className="wc-toggle-icon">{isOpen ? '×' : '+'}</span>
      </button>

      <div
        id={`panel-${project.id}`}
        className="wc-panel"
        style={{
          maxHeight: isOpen ? '240px' : '0',
          marginTop: isOpen ? '14px' : '0',
          overflow: 'hidden',
          transition: 'max-height 0.4s cubic-bezier(0.2, 0.8, 0.2, 1), margin-top 0.4s ease',
        }}
      >
        <p className="wc-note">{project.buildNote}</p>
        <div className="wc-stack">
          {project.stack.map((tech) => (
            <span key={tech}>{tech}</span>
          ))}
        </div>
        <div className="wc-links">
          {project.links.map((link) => (
            <a
              key={link.label}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className={link.secondary ? 'secondary' : ''}
              onClick={(e) => e.stopPropagation()}
            >
              {link.label}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};
