import React, { useEffect } from 'react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div id="booking-popup" className="booking-popup is-open" aria-hidden="false">
      <div className="booking-backdrop" onClick={onClose}></div>
      <div className="booking-card" role="dialog" aria-modal="true" aria-labelledby="booking-title">
        <button
          className="booking-close"
          id="bookingClose"
          onClick={onClose}
          aria-label="Close booking popup"
        >
          ×
        </button>
        <span className="booking-eyebrow">LET'S BUILD</span>
        <h2 id="booking-title">
          Ready to build<br />
          <span>your app?</span>
        </h2>
        <p className="booking-desc">Choose how you'd like to get started.</p>

        <div className="booking-links">
          <a
            className="booking-link booking-primary"
            href="https://cal.com/flutter-deviser/app-development"
            target="_blank"
            rel="noopener noreferrer"
          >
            <span className="booking-link-num">01</span>
            <span className="booking-link-copy">
              <strong>Book a Free Call</strong>
              <small>Schedule a project discussion</small>
            </span>
            <span className="booking-arrow">↗</span>
          </a>

          <div className="booking-or-divider" aria-hidden="true">
            <span>OR</span>
          </div>

          <a
            className="booking-link booking-whatsapp"
            href="https://api.whatsapp.com/send?phone=917838086198"
            target="_blank"
            rel="noopener noreferrer"
          >
            <span className="booking-link-num">02</span>
            <span className="booking-link-copy">
              <strong>DM us on WhatsApp</strong>
              <small>Chat with us directly</small>
            </span>
            <span className="booking-arrow">↗</span>
          </a>
        </div>
      </div>
    </div>
  );
};
