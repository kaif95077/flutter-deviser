import React from 'react';
import { CountryCode } from '../types';

interface FlagProps {
  countryCode: CountryCode;
  className?: string;
  width?: number;
  height?: number;
}

export const Flag: React.FC<FlagProps> = ({
  countryCode,
  className = '',
  width = 18,
  height = 12,
}) => {
  const baseStyle: React.CSSProperties = {
    display: 'inline-block',
    verticalAlign: 'middle',
    borderRadius: '1px',
    border: '1px solid rgba(17, 17, 17, 0.25)',
    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.08)',
    flexShrink: 0,
  };

  switch (countryCode) {
    case 'FR':
      // France: Blue, White, Red vertical tricolor
      return (
        <svg
          viewBox="0 0 900 600"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of France"
        >
          <rect width="300" height="600" fill="#002395" />
          <rect x="300" width="300" height="600" fill="#ffffff" />
          <rect x="600" width="300" height="600" fill="#ED2939" />
        </svg>
      );

    case 'NG':
      // Nigeria: Green, White, Green vertical tricolor
      return (
        <svg
          viewBox="0 0 600 300"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of Nigeria"
        >
          <rect width="200" height="300" fill="#008751" />
          <rect x="200" width="200" height="300" fill="#ffffff" />
          <rect x="400" width="200" height="300" fill="#008751" />
        </svg>
      );

    case 'IN':
      // India: Saffron, White, Green horizontal tricolor with Ashoka Chakra
      return (
        <svg
          viewBox="0 0 900 600"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of India"
        >
          <rect width="900" height="200" fill="#FF9933" />
          <rect y="200" width="900" height="200" fill="#ffffff" />
          <rect y="400" width="900" height="200" fill="#138808" />
          <circle cx="450" cy="300" r="60" fill="none" stroke="#000080" strokeWidth="12" />
          <circle cx="450" cy="300" r="14" fill="#000080" />
          {Array.from({ length: 24 }).map((_, i) => (
            <line
              key={i}
              x1="450"
              y1="300"
              x2={450 + 56 * Math.cos((i * 15 * Math.PI) / 180)}
              y2={300 + 56 * Math.sin((i * 15 * Math.PI) / 180)}
              stroke="#000080"
              strokeWidth="5"
            />
          ))}
        </svg>
      );

    case 'GB':
      // United Kingdom: Union Jack
      return (
        <svg
          viewBox="0 0 60 30"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of United Kingdom"
        >
          <clipPath id="uk-clip">
            <rect width="60" height="30" />
          </clipPath>
          <g clipPath="url(#uk-clip)">
            <rect width="60" height="30" fill="#012169" />
            <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6" />
            <path d="M0,0 L60,30 M60,0 L0,30" stroke="#C8102E" strokeWidth="2" />
            <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10" />
            <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6" />
          </g>
        </svg>
      );

    case 'TZ':
      // Tanzania: Green, yellow, black, yellow, blue diagonal
      return (
        <svg
          viewBox="0 0 600 400"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of Tanzania"
        >
          <defs>
            <clipPath id="tz-clip">
              <rect width="600" height="400" />
            </clipPath>
          </defs>
          <g clipPath="url(#tz-clip)">
            <rect width="600" height="400" fill="#1EB53A" />
            <polygon points="0,400 600,0 600,400" fill="#00A3DD" />
            <polygon points="0,320 600,-80 600,0 0,400" fill="#FCD116" />
            <polygon points="0,400 600,0 600,80 0,480" fill="#FCD116" />
            <polygon points="0,350 600,-50 600,50 0,450" fill="#000000" />
          </g>
        </svg>
      );

    case 'SA':
      // Saudi Arabia: Green with white inscription & sword representation
      return (
        <svg
          viewBox="0 0 600 400"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of Saudi Arabia"
        >
          <rect width="600" height="400" fill="#006C35" />
          {/* Stylized script representation */}
          <path
            d="M150,170 Q200,150 250,170 T350,170 T450,160 Q400,185 300,180 T150,170 Z"
            fill="#ffffff"
          />
          <path
            d="M180,140 Q220,130 260,145 Q310,135 360,145 Q410,130 430,140"
            stroke="#ffffff"
            strokeWidth="10"
            fill="none"
            strokeLinecap="round"
          />
          {/* Stylized sword representation */}
          <rect x="170" y="240" width="260" height="14" rx="4" fill="#ffffff" />
          <polygon points="170,236 170,258 140,247" fill="#ffffff" />
          <rect x="380" y="228" width="18" height="38" rx="3" fill="#ffffff" />
        </svg>
      );

    case 'DE':
      // Germany: Black, Red, Gold horizontal tricolor
      return (
        <svg
          viewBox="0 0 500 300"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of Germany"
        >
          <rect width="500" height="100" fill="#000000" />
          <rect y="100" width="500" height="100" fill="#DD0000" />
          <rect y="200" width="500" height="100" fill="#FFCE00" />
        </svg>
      );

    case 'CA':
      // Canada: Red, White, Red with Maple Leaf
      return (
        <svg
          viewBox="0 0 1000 500"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of Canada"
        >
          <rect width="250" height="500" fill="#D80621" />
          <rect x="250" width="500" height="500" fill="#ffffff" />
          <rect x="750" width="250" height="500" fill="#D80621" />
          {/* Iconic Canadian Maple Leaf */}
          <path
            d="M500,105 L525,185 L565,160 L555,225 L615,225 L585,270 L605,290 L520,320 L515,395 L485,395 L480,320 L395,290 L415,270 L385,225 L445,225 L435,160 L475,185 Z"
            fill="#D80621"
          />
        </svg>
      );

    case 'CD':
      // DR Congo: Sky blue with yellow-bordered red diagonal band and yellow star
      return (
        <svg
          viewBox="0 0 600 400"
          width={width}
          height={height}
          style={baseStyle}
          className={className}
          aria-label="Flag of DR Congo"
        >
          <defs>
            <clipPath id="cd-flag-clip">
              <rect width="600" height="400" />
            </clipPath>
          </defs>
          <g clipPath="url(#cd-flag-clip)">
            <rect width="600" height="400" fill="#007FFF" />
            <polygon points="0,400 0,315 600,0 600,85" fill="#F7D618" />
            <polygon points="0,382 0,332 600,18 600,68" fill="#CE1021" />
            {/* Canton Yellow Star */}
            <polygon
              points="110,62 123,98 160,98 130,120 142,156 110,133 78,156 90,120 60,98 97,98"
              fill="#F7D618"
            />
          </g>
        </svg>
      );

    default:
      return null;
  }
};
